#include<stdio.h>

struct node
{
	int pno,counter;
}frame[]={{-1,99},{-1,99},{-1,99}};
int page_found(int pno)
{           int i;
	for(i=0;i<3;i++)
	if(frame[i].pno==pno)
	return pno;
	return -1;
}
int get_mru_page()
{
	int max=0;
	if(frame[1].counter>frame[max].counter)
	  max=1;
	if(frame[2].counter>frame[max].counter)
	  max=2;
	return max;

}
int main()
{
	int p_request[]={7,0,1,2,0,3,0,4,2,3,0,3,2,1,2};
	int size=15,page_fault=0;
	int i=0,j=0;
	
	printf("\n LRU page replacement");
	printf("\npageno-------------page frames");
	for(i=0;i<size;i++)
	{
		j=page_found(p_request[i]);
		if(j==-1)
		{
			j=get_mru_page();

			frame[j].pno=p_request[i];
				page_fault++;
			printf("\n %4d-------------%4d%4d%4d",p_request[i],frame[0].pno,frame[1].pno,frame[2].pno);
		}
		else
		printf("\n %4d",p_request[i]);
		frame[j].counter=i;
	}
	printf("\n-----------------");
	printf("\n total no of page fault=%4d",page_fault);
	
}





#include<stdio.h>

#include<stdlib.h>
#include<string.h>

int process[10],proc1[10];proc[20],cbt[10],arrival[10],
	     pri[10],time[10],wait[10],turn[10];
int n,m,i,j,k,ch,type,temp,diff,tq;
float avgw,avgt;

int main()
{
   
   n=avgw=avgt=0;
   for(i=0 ; i<n ; i++)
   time[i] = 0;
   printf("enter the limit\n");
   scanf("%d",&n);
   printf("enter Processes\n");
   for(i=0;i<n;i++)
     scanf("%d",&process[i]);
   printf("enter CPU Birst Time\n");
   for(i=0;i<n;i++)

     scanf("%d",&cbt[i]);
   printf("enter Arrival Time\n");
   for(i=0;i<n;i++)
     scanf("%d",&arrival[i]);
       time[0] = 0;
   printf("Process\tCPU Burst Time\tArrival Time\n");
   for(i=0;i<n;i++)
     printf("%d\t\t%d\t\t%d\n", process[i],cbt[i],arrival[i]);
    printf("Give the time quantum:- ");
	      scanf("%d", &tq);
	      sort();
	       for(i=0;i<n;i++)
		proc1[i] = process[i];

	      rr();
	printf("\n\nThe Waiting Time of Processes :\n");
      for(i=0;i<n;i++)
       for(j=i+1;j<n;j++)
	 if(proc1[i] ==proc1[j])
	   {
	     proc1[j]= proc1[j+1];
	     n--;
	    }

    for(i=0;i<n;i++)
    printf("Process %d = %d\n", proc1[i],wait[i]);
    printf("\nThe Turn Around Time of Processes :\n");
      for(i=0;i<n;i++)
      printf("Process %d = %d\n", proc1[i],turn[i]);
    printf("\nThe Average Waiting Time of Processes = %f\n",avgw);
 
}//main

sort()
{
       for(i=0;i<n;i++)
	       for(j=i+1;j<n;j++)
		 if(arrival[i]>arrival[j])
		 {
		   temp = arrival[i];
		   arrival[i] = arrival[j];
		   arrival[j] = temp;
		   temp = process[i];
		   process[i] = process[j];
		   process[j] = temp;
		   temp = cbt[i];
		   cbt[i] = cbt[j];
		   cbt[j] = temp;
		   temp = pri[i];
		   pri[i] = pri[j];
		   pri[j]= temp;
		 }

 return;
}//sort

rr()
{
      k = 0;
     for(j=0;j<n;j++)
      for(i=0;i<n;i++)
      {
       if(cbt[i] == 0)
	 i++;
       if (cbt[i]>= tq && cbt[i] != 0)
	{
	 time[k+1] = time[k] + tq;
	 cbt[i] = cbt[i] - tq;
	 proc[k] = process[i];
	 k++;
	 j=0;
	}
       else
	{
	 if(cbt[i] != 0)
	 {
	   time[k+1] = time[k] + cbt[i];
	   proc[k] = process[i];
	   k++;
	   cbt[i] =0;
	   j=0;
	  }
	}
      }

     for(i=0;i<k;i++)
     {
       process[i] = proc[i];
    //   proc1[i] = proc[i];
     }

     print();

	//calculate waiting and turn around time
   for(i=0;i<n;i++)
     {
       temp =0;
       for(j=k-1;j>=0;j-- )
       {
	  if(proc1[i] == proc[j])
	    {
	     for(m=j-1;m>=0;m--)
		if(proc[j] == proc[m])
		{
		   temp = temp + time[j] - time[m+1] ;
		    break;
		}
	 if (i != 0)
	temp = temp+time[m];
	     }
	   }
	     wait[i] = temp;
	   }
   //turn around time
   for(i=0;i<n;i++)
     for(j=0;j<k;j++)
	if(proc1[i] == proc[j])
	  turn[i] = time[j+1];

   for(i=0;i<n;i++)
   {
     wait[i] = wait[i] - arrival[i];
     turn[i] = turn[i] - arrival[i];
   }

  //average
   for(i=0;i<n;i++)
   {
     avgw = avgw + wait[i] ;
     avgt = avgt + turn[i] ;
   }
   avgw = avgw/n;
   avgt = avgt/n;
return;
}//rr


print()
{
 printf("\nGantt Chart is \n\n");
    for(i=0;i<k;i++)
      printf("   %d\t",process[i]);
    printf("\n");
    for(i=0;i<k+1;i++)
      printf("%d\t",time[i]);
   
 return;
}//print

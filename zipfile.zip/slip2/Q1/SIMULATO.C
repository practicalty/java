#include<stdio.h>
#include<conio.h>
long int memcode[50];
loadfile()
{
	int i=100;
	char name[30];
	//clrscr();
	FILE *fp;
	printf("enter the file name");
	scanf("%s",name);
	fp=fopen(name,"r");
	if(fp==NULL)
	{
		printf("file does not exist");
		exit(0);
	}
	while(!feof(fp))
	{
	     fscanf(fp,"%ld",&memcode[i]);
	     i++;
	}
	fclose(fp);
}

	execute()
	{
	    int reg[6],j=100,opd1,opd2,code,opcode[1000],flag[6];
	    while(1)
	    {
		code=memcode[j]/10000;
		opd1=(memcode[j]/1000)%10;
		opd2=memcode[j]%1000;
		switch(code)
		{
		    case 0:
			    return(0);
		    case 1:
			   reg[opd1]+=opcode[opd2];
			   break;
		    case 2:
			   reg[opd1]-=opcode[opd2];
			   break;
		    case 3:
			      reg[opd1]*=opcode[opd2];
			       break;
		    case 4:
			    reg[opd1]=opcode[opd2];
			    break;
		    case 5:
			    opcode[opd2]=reg[opd1];
			    break;
		    case 6:
			    if(reg[opd1]<opcode[opd2])
			    flag[1]=1;
			     if(reg[opd1]<=opcode[opd2])
			    flag[2]=1,flag[3]=1;
			    if(reg[opd1]>opcode[opd2])
			    flag[5]=1;

			   if(reg[opd1]>=opcode[opd2])
			    flag[5]=1,flag[3]=1;
			    flag[5]=1;
		  case 7:if(flag[opd1]==1)
			 j=opd2-1;
			 break;
		  case 8:
			   reg[opd1]/=opcode[opd2];
			    break;
		   case 9:
			   printf("enter the value");
			   scanf("%ld",&opcode[opd2]);
			   break;
		   case 10:
			     printf("%d",opcode[opd2]);
			     break;
		  }
		  j++;
		}
	      }
	      void main()
	      {
	      int ch;
		     do{

	      printf("menu\n");
	      printf("1.load\n2.execute\n3.exit\n");
	      printf("Enter ur choice");
	      scanf("%d",&ch);
		    switch(ch)
		    {
		    case 1:
				  loadfile();
				  break;
		    case 2:
				   execute();
				   break;
		     case 3:
				    exit(0);
		     }
		  }while(1);


	}

/*__________________________________________________
   Name         :Pravin Sonar & Amol Ahire
   Roll No      :321 & 329
   Title        :Simulation program using FCFS.
   Date         :21/12/2010
____________________________________________________*/

#include<stdio.h>
struct job
{
		int at,bt,wt,tat,index;
};
main()
{
		struct job p[15],temp;
		int i,j,clk,idl,ttat=0,twt=0,MAX,c[15];

	float atat=0,awt=0;
	 clrscr();
	printf("Enter the number of jobs u have:");
	scanf("%d",&MAX);
		for(i=0;i<MAX;i++)
		{
				printf("\n Enter arrival time for job %d:",i+1);
				scanf("%d",&p[i].at);
				p[i].bt=0;
				while(p[i].bt==0)
				p[i].bt=rand()%10;
				p[i].index=i+1;
		}
		printf("\n Job\tBust Time\tArrival Time");
		for(i=0;i<MAX;i++)
		{
				printf("\n J%d\t\t%d\t\t %d",p[i].index,p[i].bt,p[i].at);
		}
		for(i=0;i<MAX;i++)
		{
				for(j=i+1;j<MAX;j++)
				{
						if(p[i].at>p[j].at)
						{
								temp=p[j];
								p[j]=p[i];
								p[i]=temp;
						}
				}
		}
		clk=0;
		idl=0;
		printf("\n\n Gantt Chart:\n");
		for(i=0;i<MAX;i++)
		{
				if(clk<p[i].at)
				{
						idl+=p[i].at-clk;
						clk=p[i].at;
						printf("|CPU Idle|%d",clk);
				}
				p[i].wt=clk-p[i].at;
				clk=clk+p[i].bt;
				p[i].tat=clk-p[i].at;
			c[i]=clk;
		//ttat=ttat+p[i].tat;
			printf("| P%d ",p[i].index);

	}
		printf("|");
	printf("\n%d",clk);
	for(i=0;i<MAX;i++)
		printf("   %d",c[i]);
	printf("\n\n\n After Execution\n");
		printf("\n Job\tBust Time\tArrival Time\tWaitting  Time\tTurn Around time");
		for(i=0;i<MAX;i++)
		{
				printf("\n J%d\t\t%d\t\t%d\t\t%d\t\t%d",p[i].index,p[i].bt,p[i].at,p[i].wt,p[i].tat);
	}
	printf("\n");

	for(i=0; i<MAX; i++)
	{
		twt+=p[i].wt;
	}
	 for(i=0; i<MAX; i++)
		{
				ttat+=p[i].tat;
		}
	awt=twt/MAX;
	atat = ttat/MAX;
	printf("\nAverage waiting time is %0.2f",awt);
	printf("\nAverage turn around time is %0.2f\n\n",atat);
}

/*_______OUTPUT___________________

[ty27b2@uglinux ass2]$ ./a.out
Enter the number of jobs u have:5

 Enter arrival time for job 1:1

 Enter arrival time for job 2:2

 Enter arrival time for job 3:3

 Enter arrival time for job 4:4

 Enter arrival time for job 5:0

 Job    Bust Time       Arrival Time
 J1             3                1
 J2             6                2
 J3             7                3
 J4             5                4
 J5             3                0

 Gantt Chart:
| P5 | P1 | P2 | P3 | P4 |
24   3   6   12   19   24


 After Execution

 Job    Bust Time       Arrival Time    Waitting  Time  Turn Around time
 J5             3               0               0               3
 J1             3               1               2               5
 J2             6               2               4               10
 J3             7               3               9               16
 J4             5               4               15              20

Average waiting time is 6.00
Average turn around time is 10.8
*/






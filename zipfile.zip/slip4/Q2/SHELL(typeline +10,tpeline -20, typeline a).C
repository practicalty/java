/* PROGRAM TO IMPLEMENT TOYSHELL*/

#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <string.h>
#include <process.h>
#include <alloc.h>
#include <dir.h>
#include<stdlib.h>

#define ENTER  7181
#define CTRL_D 8196
#define SPACE  14624
#define TAB   3849

#define attrib FA_RDONLY|FA_HIDDEN|FA_SYSTEM|FA_LABEL|FA_DIREC|FA_ARCH

int ch,reply,i;
FILE *fp,*fpout,*fpin;
char fname[15],t1[15], t2[15], t3[35],t4[15];
char comm[200],*ptr,str[100];
struct ffblk f;


void main()
{
	clrscr();
	do
	{
		//.... display prompt
		printf("myshell$ ");
		//.... accept command
		accept_command();
		//.... take action on command
		take_action();
	  }while(1);
}// main

int accept_command()
{
	int i;
	i=0;
	ch = bioskey(0);
	while ( ch != ENTER )
	{
		if( ch == CTRL_D)
		   exit(0);
		   printf("%c",ch);
		   comm[i++] = ch;
		  ch = bioskey(0);
	} // while
	comm[i] = '\0';
	printf("\n");
	return;
}

int take_action()
{
	char str[100];
	int reply;
	if( strlen(comm) == 0 )
		return; // no action
	else
	if( strcmp( comm,"exit") == 0 )
		exit(0);
	else
	if(strncmp(comm, "typeline",8) == 0)
		 type();
	return;
}

type()
{
  FILE *fpin, *fpout;
  char buff[80],mem[100][80];
  char t1[15], t2[15], t3[35],cwd[100];
  int t,count=0,i,ln=0;
  strset(t1,'\0');
  strset(t2,'\0');
  strset(t3,'\0');
  flushall();

  sscanf(comm, "%s %s %s",&t1,&t2,&t3);
     if(t2[0] == 'a')
	t = 500;
     else
	t = atoi(t2);
     reply = findfirst(t3 , &f, attrib);
     fpout = stdout;
     while(reply != -1 )
      {
	fpin=fopen(f.ff_name,"r");
	if(fpin != NULL)
	{
	  printf("\n File name :- %s\n", f.ff_name);
	   if (t > 0)
	   while(!feof(fpin) )
	  {

		if (t == count)
		   break;
		else
		{
		   strset(buff,'\0');
		   fgets(buff,80,fpin);
		   fprintf(fpout,"%s",buff);
		   count++;
		}
	  } //while
	  else
	  if (t < 0 )
	  {
	  while(!feof(fpin) )
	     fscanf(fpin,"%s",&mem[ln++]);
	   t = abs(t);
	   i=ln-2 ;
	   while( t != count )
	   {
	     fprintf(fpout,"%s\n",mem[i]);
	     count++;
	     i--;
	    }
	  }
	  fclose(fpin);
	} //if
	reply=findnext(&f);
      } //while

   return(0);
}  //type


#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
//#include<sys/wait.h>
#include<sys/types.h>
//#include<sys/fcntl.h>
#include<sys/stat.h>
#include<dirent.h>

int pcount=0;

char **create_argvector(char *s)
{
 int i=0,j=0,k=0;
 char **av,s1[20];
 av=(char **)malloc(10*sizeof(char *));
 for(i=0;s[i]!='\n';i++)
 {
  if(s[i]!=' ')
    s1[j++]=s[i];
    else
    {
     s1[j]='0';
     av[k]=(char *)malloc(sizeof(s1));
     strcpy(av[k++],s1);
     j=0;
     }
     }
      s1[j]='0';
      pcount=k+1;
      av[k]=(char *)malloc(sizeof(s1));
      strcpy(av[k++],s1);
      av[k]=(char *)malloc(2);
      av[k]=(char *)0;
      return av;
      }

      void counting(char *option,char *fname)
      {
      FILE *fp1;
      char s1[80],c1,c2;
      int lct,cct,wct,i;
      fp1=fopen(fname,"r");
      if(fp1==NULL)
       printf("\nFILE NOT FOUND");
       else
       {
       lct=wct=cct=0;
       c1=fgetc(fp1);
       while(c1!=EOF)
       {
	c2=fgetc(fp1);
	if(c2==EOF)
	break;
	if(((c2==' ')||(c2=='\t')||(c2=='\n'))&&((c1!=' ')||(c1!='\t')||(c1!='\n')))
	wct++;
	if(c2=='\n')
	lct++;
	cct++;
	c1=c2;
	}
      }
      fclose(fp1);
      if(strcmp(option,"1")==0)
      printf("\n%d",lct);
      else if(strcmp(option,"W")==0)
      printf("\n%d",wct);
      else if(strcmp(option,"C")==0)
      printf("\n%d",cct);
      else
       printf("\nINVALID COMMAND OPTION!");
       }

       void main()
       {
       int pid,pid_t;
       int status;
       char s1[80],**v;
       while(1)
       {
       printf("\nMY SHELL$");
       strcpy(s1," ");
       fgets(s1,80,stdin);
       if(strcmp(s1),"q\n"==0)
       break;
       else
       {
	v=create_argvector(s1);
	if((pid=fork())<0)
	printf("\nPROCESS ERROR!");
	else if(pid==0)
	{
	if((strcmp(v[0],"count")==0)&&(pcount==3))
	counting(v[1],v[2]);
	else
	{
	execvp(v[0],v);
	printf("\nCANNOT EXECUTE THE COMMAND!");
	exit(127);
	}
      }
	else
	if((pid==waitpid(pid,&status,0))<0)
	printf("\n ERROR WAITING");
	}
      }
    }






#include<stdio.h>
//#include<conio.h>
#include<stdlib.h>
long int memcode[50];

loadfile()
{
	int i=100;
	char name[30];
	//clrscr();
	FILE *fp;
	printf("enter the file name\n");
	scanf("%s",name);
         printf("\n");
	fp=fopen(name,"r");
	if(fp==NULL)
	{
		printf("file does not exist");
		exit(0);
	}
	while(!feof(fp))
	{
	     fscanf(fp,"%ld",&memcode[i]);
	     i++;
	}
	fclose(fp);
}


	execute()
	{
	    int reg[6],j=100,flag[6],opcode[1000],temp;
            long int opd1,opd2,code;
	    while(1)
	    {
		code=memcode[j]/10000;        // For Opcode
		opd1=(memcode[j]/1000)%10;   // operand1
		opd2=memcode[j]%1000;        // operand2    
		switch(code)
		{
		    case 0:
			    return(0); //Exit
		    case 1:
			   reg[opd1]+=opcode[opd2]; //ADD
			   break;
		    case 2:
			   reg[opd1]-=opcode[opd2]; //SUB
			   break;
		    case 3:
			      reg[opd1]*=opcode[opd2]; //MUL
			       break;
		    case 4:
			    reg[opd1]=opcode[opd2];  //MOVER
			    break;
		    case 5:
			    opcode[opd2]=reg[opd1];  //MOMVEM
			    break;
		    case 6:
			    	if(reg[opd1]<opcode[opd2]) //LT
			    		 flag[1]=1;
			     
				if(reg[opd1]<=opcode[opd2]) //LE,EQ
			    		flag[2]=1,flag[3]=1;
				
			    	if(reg[opd1]>opcode[opd2]) //GT
			    		flag[4]=1;
				
			  	 if(reg[opd1]>=opcode[opd2]) //GE,EQ
			    		flag[5]=1,flag[3]=1;
					flag[6]=1;
                            break;

		  case 7: if(flag[opd1]==1)   //BC
			  j=opd2-1;
			  break;
		  case 8:
			   reg[opd1]/=opcode[opd2]; //DIV
			    break;
		   case 9:
			   printf("\nENTER THE VALUE\n");  // READ
			   scanf("%ld",&opcode[opd2]);
			   break;
		   case 10:                                             
			     printf("\n\n Result is= %ld",opcode[opd2]);   //PRINT
			     break;
                   case 11:      //int temp; //swap                             
                                 temp=reg[opd1];
                                 reg[opd1]=opcode[opd2];
                                 opcode[opd2]=temp;
                                 printf("\n SWAPED VALUE IS:%ld%ld",reg[opd1],opcode[opd2]);
                                 break;
                   case 12:
                             reg[opd1]=reg[opd1]+1;
                             break;
                   case 13:

                            reg[opd1]=reg[opd1]-1;
                             break;                              
                   case 14:
                            opcode[opd2]=opcode[opd2]+1;
                            break;
                   case 15:
                            opcode[opd2]=opcode[opd2]-1;
                            break;
                   case 16:
                            opcode[opd1]=reg[opd1]+opcode[opd2];
                            break;
                      
                   case 17:
                            opcode[opd1]=reg[opd1]-opcode[opd2];
                            break;
                   case 18:
                            reg[opd1]=reg[opd1]*opcode[opd2];
                            break;
                   case 19:
                           reg[opd1]=opcode[opd2]/reg[opd1];
                           break;
                   case 20:
                            printf("\nRESULt:%ld",reg[opd1]);
                             break;
                   case 21: 
                            printf("\nENTER THE VALUE");
                            scanf("%d",&reg[opd1]);
                            break;
                   case 22:
                             reg[opd1]=reg[opd1]=0;
                             break;
                   case 23:
                             reg[opd1]=reg[opd1]=1;
                             break;                           
		  }

		  j++;
		}
	      }
	      void main()
	      {
	      int choice;
		do
                 {

	      printf("\n\nmenu\n");
	      printf("1.load\n2.execute\n3.exit\n");
	      printf("Enter ur choice=\t");
	      scanf("%d",&choice);
	    switch(choice)
		    {
		     case 1:
				  loadfile();
				  break;
		     case 2:
				   execute();
				   break;
		      case 3:
				    exit(0);
		     }  //switch-case
	    }while(1);  //do-while


	}//main

#include<stdio.h>
#include<conio.h>
#include<process.h>
#include<string.h>
#include<stdlib.h>

char *error_list[]={"Error....file not found","Error formal parameter missing","Error parameter not found"};

struct mnt_record
{
	char mname[8];
	int kpcount,ppcount,mdtptr,kpdtptr;
}mnt[5];
struct mdt_record
{
	char label[9];
	char mopcode[9];
	char op1[40];
	char op2[9];
}mdt[50];

struct kpdtab_entry
{
	char pname[9];
	char value[9];
}kpdtab[20];

char pntab[10][9];
int fpcount=0,mnt_ct=0,mdt_ct=0,kpdt_ct=0,mfound_flag=0,pntab_ct=0;
FILE *fp1;

int validate_command(char *str,char *delimit)
{
	int count=0;
	char *s;
	s=strtok(str,delimit);
	while(s!=NULL)
	{
		count++;
		s=strtok(NULL,delimit);
	}
	return count;
}
void show_error(int errno,int flag)
{
	printf("\n %s",error_list[errno]);
	if(flag==1)
		exit(0);
}
int findfp(char *str)
{
	int i;
	for(i=0;i<fpcount;i++)
		if(strcmp(pntab[i],str)==0)
			return i;
	return -1;
}

void process_token(char *str,int type)
{
	int i;
	if(str[0]=='&')
	{
		i=findfp(str);
		if(i==-1)
			show_eoor(2,1);
		switch(type)
		{
			case 1: itoa(i,mdt[mdt_ct].label,10);
				break;
			case 2: itoa(i,mdt[mdt_ct].mopcode,10);
				break;
			case 3: itoa(i,mdt[mdt_ct].op1,10);
				break;
			case 4: itoa(i,mdt[mdt_ct].op2,10);
				break;
		}
	}
	else
	{
		switch(type)
		{
			case 1:strcpy(mdt[mdt_ct].label,str);
				break;
			case 2: strcpy(mdt[mdt_ct].mopcode,str);
				break;
			case 3: strcpy(mdt[mdt_ct].op1,str);
				break;
			case 4: strcpy(mdt[mdt_ct].op2,str);
				break;
		}
	}
}

void process_macro()
{
	char s1[80],s2[80],s3[80],pname[10][20];
	char plist[40],*op1,*op2,oper[20],label[9],*mopcode;
	int i,tcount,k,kpct,ppct,flag=1;
	fgets(s1,80,fp1);
	s1[strlen(s1)-1]='\0';
	kpct=0;ppct=0;
	pntab_ct=0;
	while(strcmp(s1,"MEND")!=0)
	{
		strcpy(s2,s1);
		if(flag==1)
		{
			strcpy(mnt[mnt_ct].mname,strtok(s2," "));
			strcpy(mdt[mdt_ct].mopcode,mnt[mnt_ct].mname);
			strcpy(plist,strtok(NULL," "));
			strcpy(mdt[mdt_ct].op1,plist);
			strcpy(s3,plist);
			if(fpcount==0)
				show_error(1,0);
				strcpy(pname[0],strtok(plist,","));
				for(i=0;i<fpcount;i++)
					if(strchr(pname[i],'=')!=NULL)
					{
						strcpy(pntab[pntab_ct],strtok(pname[i],"="));
						strcpy(kpdtab[kpdt_ct].pname,pname[pntab_ct]);
						strcpy(oper,strtok(NULL," "));
						if(oper!=NULL)
							strcpy(kpdtab[kpdt_ct].value,oper);
						kpdt_ct++;
						kpct++;
						pntab_ct++;
						mnt[mnt_ct].kpdtptr=kpdt_ct-kpct;
					}
					else
					{
						strcpy(pntab[pntab_ct],pname[i]);
						pntab_ct++;
						ppct++;
					}
					mnt[mnt_ct].ppcount=ppct;
					mnt[mnt_ct].kpcount=kpct;
					mnt_ct++;
					mdt_ct++;
					flag=0;
				}
				else
				{
					tcount=validate_command(s2," ");
					strcpy(s2,s1);
					if(tcount==3)
					{
						strcpy(label,strtok(s2," "));
						process_token(label,1);
						strcpy(mopcode,strtok(NULL," "));
						process_token(mopcode,2);
						strcpy(oper,strtok(NULL," "));
						if(strchr(oper,',')!=NULL)
						{
							op1=strtok(oper,",");
							process_token(op1,3);
							op2=strtok(NULL," ");
						}
						else
							op2=oper;
						process_token(op2,4);
					}
					else
					{
						strcpy(mopcode,strtok(s2," "));
						process_token(mopcode,2);
						strcpy(oper,strtok(NULL," "));
						if(strchr(oper,',')!=NULL)
						{
							op1=strtok(oper,"");
							process_token(op1,3);
							op2=strtok(NULL," ");
						}
						else
							op2=oper;
						process_token(op2,4);
					}
					mdt_ct++;
				}
				fgets(s1,80,fp1);
				s1[strlen(s1)-1]='\0';
			}
			strcpy(mdt[mdt_ct++].mopcode,"MEND");
		}
		int findkp(char str,int k)
		{
			int i;
			for(i=mnt[k].kpdtptr;i<mnt[k].kpdtptr+mnt[k].kpcount;i++)
				if(strcmp(str,kpdtab[i].pname)==0)
			return i;
			return -1;
		}


		void main()
		{
			char fname[12],s1[80],s2[80],pname[10][20];
			char*mopcode,*s3,*plist;
			int tcount,k,i,j,flag;
			clrscr();
			printf("\n Enter the filename");
			gets(fname);
			fp1=fopen(fname,"r");
			if(fp1==NULL)
				show_error(0,1);
			fgets(s1,80,fp1);
			s1[strlen(s1)-1]='\0';
			strcpy(s2,s1);
			if(strcmp(s1,"MACRO")!=0)
			{
				printf("\nNo Macro, Start Assembler");
				exit(1);
			}
			while(strcmp(s1,"MACRO")==0);
			{
				strcpy(mdt[mdt_ct].mopcode,"MACRO");
				mnt[mnt_ct].mdtptr=mdt_ct;
				mdt_ct++;
				process_macro();
				fgets(s1,80,fp1);
				s1[strlen(s1)-1]='\0';
				strcpy(s2,s1);
			}

		printf("\n Macro name table");
		printf("-------------------------");
		printf("\n Macro_name    #pp   #kp   MDTPTR    KPDTPTR");
		for(i=0;i<mnt_ct;i++)
		printf("\n %-10s     %3d      %3d      %6d    %7d",mnt[i].mname,mnt[i].ppcount,mnt[i].kpcount,mnt[i].mdtptr,mnt[i].kpdtptr);
		printf("\n\n Macro Defination table");
		printf("------------------------------");
		for(i=0;i<mdt_ct;i++)
			printf("\n %8s     %8s    %20s    %8s",mdt[i].label,mdt[i].mopcode,mdt[i].op1,mdt[i].op2);
		printf("\n press any key to continue");
		getch();
		printf("keyword parameter default table[kpdtab]");
		printf("-----------------------");
		printf("\n Parameter name value");
		printf("----------------");
		for(i=0;i<kpdt_ct;i++)
		printf("\n %4s   %14s   %9s",kpdtab[i].pname,kpdtab[i].value);
		printf("press any key to continue...");
		getch();

}


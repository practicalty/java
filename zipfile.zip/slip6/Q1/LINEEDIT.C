#include<stdio.h>
#include<conio.h>
struct line
{
char string[50];
struct line *next;
};
struct line *create();
struct line *insert(struct line*head);
struct line*delete(struct line*head);
save(struct line*head);
struct line*load();
struct line *move();
struct line*deleterange(struct line *temp);
void main()
{
struct line *head;
int ch;
clrscr();
do
{
printf("menu");
printf("1.create\n2.display\n3.insert\n4.delete\n5.save\n6.move\n7.load\n8.deleterange\n9.help\n10.append\n11.exit");

printf("enter ur choice");
scanf("%d",&ch);
switch(ch)
{
case 1:
	 head=create();
	 break;
case 2:
	  display(head);
	  break;
case 3:
	     head=insert(head);
	     break;
case 4:
	     head=delete(head);
	     break;
case 5:
	      save(head);
	      break;
case 6:
	       head=move(head);
	       break;
case 7:
	      head=load(head);
	      break;
case 8:
	       head=deleterange(head);
	       break;
case 9:
		 help();
		  break;
case 10:
	       append(head);
	       break;
case 11:
		 exit(0);
}
}while(1);
getch();
}
struct line *create()
{
struct line * temp,*newn,*head=NULL;
char yn;
do
{
printf("enter the line");
newn=malloc(sizeof(struct line));
scanf("%s",newn->string);
newn->next=NULL;
if(head==NULL)
{
head=newn;
temp=newn;
}
else
{
temp->next=newn;
temp=newn;
}
printf("want to continue");
flushall();
scanf("%c",&yn);
}while(yn!='n');
return(head);
}
display(struct line *temp)
{
int i=1;
//char string;
while(temp!=NULL)
{
printf("%d\t%s\n",i,temp->string);
temp=temp->next;
i++;
}
}
struct line *insert(struct line*head)
{
int line,ctr=1,flag=0;
struct line*temp=head,*newn,*prv;
printf("enter line no");
scanf("%d",&line);
printf("Enter data for new line");
newn=malloc(sizeof(struct line));
scanf("%s",newn->string);
newn->next=NULL;
if(ctr==line)
{
newn->next=head;
head=newn;
}
else
{
while(temp!=NULL)
{
ctr++;
prv=temp;
temp=temp->next;
if(ctr==line)
{
prv->next=newn;
newn->next=temp;
flag=1;
break;
}
}
}
if(flag==0)
{
prv->next=newn;
}
return(head);
}
struct line*delete(struct line*head)
{
int ctr=1,line,flag=0;
struct line *temp=head,*prv;
printf("enter the line no");
scanf("%d",&line);
if(ctr==line)
{
head=head->next;
flag=1;
free(temp);
}
else
{
while(temp!=NULL)
{
ctr++;
prv=temp;
temp=temp->next;
if(ctr==line)
{
prv->next=temp->next;
free(temp);
flag=1;
break;
}
}
}
if(flag==0)

printf("line no does not exits");
else
printf("line no successfully deleted");
return(head);
}
save(struct line*head)
{
FILE *fp;
fp=fopen("temp.txt","w");
while(head!=NULL)
{
fprintf(fp,"%s\n",head->string);
head=head->next;
}
fclose(fp);
}
struct line*load()
{
FILE *fp;
struct line *temp,*head=NULL,*newn;
fp=fopen("temp.txt","r");
newn=malloc(sizeof(struct line));
fscanf(fp,"%s",newn->string);
newn->next=NULL;
while(!feof(fp))
{
if(head==NULL)
{
head=newn;
temp=newn;
}
else
{
temp->next=newn;
temp=newn;
}
newn=malloc(sizeof(struct line));
fscanf(fp,"%s",newn->string);
newn->next=NULL;

}
fclose(fp);
return(head);
}
struct line *move(struct line *head)
{
struct line *newn,*temp,*prv;
int ctr=1,lno,pos,flag=0;
printf("Enter the line no to move");
scanf("%d",&lno);
printf("Enter the pos to move");
scanf("%d",&pos);
newn=malloc(sizeof(struct line));
newn->next=NULL;
if(ctr==lno)
{
strcpy(newn->string,head->string);
head=head->next;
free(temp);
}
else
{
while(temp!=NULL)
{
ctr++;
prv=temp;
temp=temp->next;
if(ctr==lno)
{
strcpy(newn->string,temp->string);
prv->next=temp->next;
free(temp);
}
}
}
ctr=1;
if(pos==ctr)
{
newn->next=head;
head=newn;
}
else
{
while(temp!=NULL)
{
ctr++;
prv=temp;
temp=temp->next;
if(ctr==pos)
{
prv->next=newn;
newn->next=temp;
flag=1;
break;
}
}
}
if(flag==0)
{
prv->next=newn;
}
return(head);
}
append(struct line *temp)
{
struct line *newn;
printf("enter string");
newn=malloc(sizeof(struct line));
scanf("%s",newn->string);
newn->next=NULL;
while(temp->next!=NULL)
{
temp->next=newn;
}
}
struct line*deleterange(struct line *head)
{
struct line *temp=head,*prv,*newn;
int pos,endpos,ctr=1,i;
printf("Enter the starting pos");
scanf("%d",&pos);
printf("enter ending pos");
scanf("%d",&endpos);
if(ctr==pos)
{
for(i=pos;i<=endpos;i++)
{
head=head->next;
free(temp);
temp=head;
}
}
else
while(temp!=NULL)
{
ctr++;
prv=temp;
temp=temp->next;
if(ctr==pos)
{
for(i=pos;i<=endpos;i++)
{
prv->next=temp->next;
free(temp);
}
}
}
return(head);
}
help()
{
char c;
while(1)
{
char ch;
printf("menu\n");
printf("1.c.create\n2.i.insert\n3.m.move\n4.p.copy\n5.d.delete\n6.s.save\n7.h.help\n8.t.deleterange\n9.append\n10,e.exit");
printf("enter ur choice");
scanf("%c",&ch);
switch(ch)
{
case 'a':
	   printf("it appends at the end");
	   break;
case 'l':
	   printf("it loads the data");
	   break;
case 'c':
	   printf("it creats  line editor");
	   break;
case'i':
	    printf("it inserts the line");
	    break;
case'm':
	      printf("it moves the line");
	      break;
case'p':
	     printf("it copies the data");
	     break;
case't':
	      printf("it delets range of lines");
	      break;
case's':
	       printf("it saves the file");
	       break;
case'd':
	     printf("it deletes the line");
	     break;
case'e':
	    return(0);
}
}
}
#include<stdio.h>
#include<conio.h>


int max[5][4]={{0,0,1,2},{1,7,5,0},{2,3,5,6},{0,6,5,2,},{0,6,5,6}};
int allocation[5][4]={{0,0,1,2},{1,0,0,0},{1,3,5,4},{0,6,3,2},{0,0,1,4}};
int need[5][4],total[]={10,5,7};
int available[4],work[4],request[4],finish[5],seq[5],m=5,n=4;

void get_need_available()
{
 int i,j,s1=0,s2=0,s3=0;
	for(i=0;i<m;i++)
	 {
	  s1=s1+allocation[i][0];
	  s2=s2+allocation[i][1];
	  s3=s3+allocation[i][2];
	     for(j=0;j<n;j++)
	       need[i][j]=max[i][j]-allocation[i][j];
	   }
	   available[0]=total[0]-s1;
	   available[1]=total[1]-s2;
	   available[2]=total[2]-s3;
}

void  printall()

  {

    int i,j;
    printf("\nPROCEES ID .......ALLOCATION..0..........MAX........NEED");
    for(i=0;i<m;i++)
    {
      printf("\n p%d",i);
      printf(" %4d%4d%4d.....%4d%4d%4d.....%4d%4d%4d  ",allocation[i][0],allocation[i][1],allocation[i][2],max[i][0],max[i][1],max[i][2],need[i][0],need[i][1],need[i][2]);
     }
     printf("TOTAL   :   %4d%4d%4d      ",total[0],total[1],total[2]);
     printf("AVAILABLE : %4d%4d%4d",available[0],available[1],available[2]);
   }


   void main()
   {
   int i,flag;
   clrscr();
   get_need_available();
   printall();

   while((flag=issafe())==1)
      {
       printf("\n SYSTEM IS IN SAFE STATE AND  SEQUENCE =    ");
/* void safe_sequence()
      {
	for(i=0;i<m;i++)
	  printf("%4d",&seq[i]);
	  }
*/
       printf("REQUEST FROM PROCESS  :    ");
       scanf("%d",&i);
	 if (i<0)
	 break;
	 printf("\n ENTER REQUEST : ");
	 scanf("%d%d%d",&request[0],&request[1],&request[2]);
	   if(!update(i))
	   break;

	   printf("\n\n");
	   printall();
      }

      if(flag==0)
      printf("SYSTEM IS NOT IN SAFE STATE");

      getch();
  }

  int issafe()
  {
   int j,k,t=0,flag1=1,flag2;
     for(j=0;j<m;j++)
       finish[j]=0;
       for(j=0;j<n;j++)
	j=0;
	while(flag1)
	 {
	  flag1=0;
	    while(j<m)
	    {
	      if(finish[j]==0)

	       flag2=1;
	       for(k=0;k<n;k++)
	       {
		if(need[j][k]>work[k])
		{
		  flag2=0;
		  break;
		  }
		}
			 if(flag2==1)
			   {
			    for(k=0;k<n;k++)
			      work[k]+=allocation[j][k];
			      finish[j]=1;
			      seq[t++]=j;
			      j=0;
			      flag1=1;
			      break;
			      }
			   }
			     j++;
		}
		     if(flag1==0)

			for(k=0;k<m;k++)
			{
			finish[k]==0;
		       return 0;
		       }
		       return 1;
		     }


  int update(int i)
  {
   int j;
   for(j=0;j<n;j++)
   if (request[j]>need[i][j])
   {
   printf("\n INVALID REQUEST : ");
   return 0;
   }

   for(j=0;j<m;j++)
    if(request[j]>available[j])
    {
     printf("PROCESS MUST WAIT  ");
     return 1;
     }

      for(j=0;j<n;j++)
	{
	 allocation[i][j]+=request[j];
	 need[i][j]-=request[j];
	 available[j]-=request[j];
	}
	return 1;
	}











#include<stdio.h>
#include<conio.h>
#include <string.h>
struct macroname
{
char mname[30];
int pp,kp,ev,mdtpt,kpp,ppp;
}mnt[30];
struct formal
{
char name[30],pos[30];
}fpt[30];
struct actual
{
char name[30],pos[30];
}apt[30];
char mname[30],fname[30],temp1[30];
char mdt[30][80];
int mntcnt=0,fptcnt=0,aptcnt=0,mdtcnt=0,i=0,j=0,ectr=0,m=0;
char filename[30],file[30][80],temp[30],expcode[30][80];
int p=0,c=0,k=0,z,kpc=0,evc=0,pppcnt=0,kppcnt=0;
FILE *fp;
char fname[30];
void main()
{
clrscr();
printf("Enter file name\n");
scanf("%s",filename);
fp=fopen(filename,"r");
while(!feof(fp))
  {
     fgets(file[i],80,fp);
     i++;
  }
  fclose(fp);
  while(j<i)
  {
    if(strcmpi(file[j],"macro\n")==0)
    {
      j++;
      for(k=0;file[j][k]!=' '&&file[j][k]!='\n';k++)
      mname[k]=file[j][k];
      mname[k]='\0';
      if(file[j][k]!='\n')
      {
      c=1;
	while(1)
	{
	  k++;
	  p=0;
	  for(;file[j][k]!=','&&file[j][k]!='\n';k++)
	  fname[p++]=file[j][k];
	  fname[p]='\0';
	  strcpy(fpt[fptcnt].name,fname);
	  itoa(c,temp1,10);
	  strcpy(temp,"#");
	  strcat(temp,temp1);
	  strcpy(fpt[fptcnt].pos,temp);
	  fptcnt++;
	  if(file[j][k]!=',')
	  break;
	  c++;
	}//while
      }//if
      else
       c=0;
     strcpy(mnt[mntcnt].mname,mname);
     mnt[mntcnt].pp=c;
     mnt[mntcnt].kp=kpc;
     mnt[mntcnt].ev=evc;
     mnt[mntcnt].mdtpt=mdtcnt;
     mnt[mntcnt].kpp=kppcnt;
     mnt[mntcnt].ppp=pppcnt;
     mntcnt++;
       while(1)
       {
	 j++;
	 if(strcmpi(file[j],"mend\n")==0)
	 {
	 strcpy(mdt[mdtcnt],"mend");
	 mdtcnt++;
	 break;
	 }
	 p=0;
	 for(k=0;file[j][k]!='&' && file[j][k]!='\n';k++)
	 temp[k]=file[j][k];
	 temp[k]='\0';

	  while(1)
	 {
	  for(p=0;file[j][k]!='\n'&&file[j][k]!=' '&&file[j][k]!=',';k++)
	  fname[p++]=file[j][k];
	  fname[p]='\0';

	 for(z=0;z<fptcnt;z++)
	 if(strcmpi(fname,fpt[z].name)==0)
	 break;
	 strcat(temp,fpt[z].pos);
	 if(file[j][k]=='\n')
	 break;
	 k++;
	}//while
	 //strcat(fname,temp);

	 strcpy(mdt[mdtcnt],temp);
	 mdtcnt++;
	}//while
      }//if
      else
      {
	for(k=0;file[j][k]!=' '&&file[j][k]!='\n'&&file[j][k]!='\0' ;k++)
	temp[k]=file[j][k];
	temp[k]='\0';
	for(z=0;z<mntcnt;z++)
	if(strcmpi(temp,mnt[z].mname)==0)
	break;
	if(z<mntcnt)
	{
	if(file[j][k]!='\n')
	{
	c=1;
	  while(1)
	  {
	    k++;
	    p=0;
	    for(;file[j][k]!=','&&file[j][k]!='\n';k++)
	    fname[p++]=file[j][k];
	    fname[p]='\0';
	    strcpy(apt[aptcnt].name,fname);
	  itoa(c,temp1,10);
	  strcpy(temp,"#");
	  strcat(temp,temp1);
	  strcpy(apt[aptcnt].pos,temp);
	  aptcnt++;
	  if(file[j][k]!=',')
	  break;
	  c++;
	  }//while
	  }
	else
	{
	   c=0;
	}//else
      }//if
      }//else
      j++;
     }


      printf("macro name table\n");
      for(k=0;k<mntcnt;k++)
      printf("%s\t%d\t%d\t%d\t%d\t%d\t%d\n",mnt[k].mname,mnt[k].pp,mnt[k].kp,mnt[k].ev,mnt[k].mdtpt,mnt[k].kpp,mnt[k].ppp);
      printf("functional para table\n");
      for(k=0;k<fptcnt;k++)
      printf("%s\t%s\n",fpt[k].name,fpt[k].pos);
      printf("actual para table\n");
      for(k=0;k<aptcnt;k++)
      printf("%s\t%s\n",apt[k].name,apt[k].pos);
      printf("macro def table\n");
      for(k=0;k<mdtcnt;k++)
      printf("\t%s\n",mdt[k]);
      pass2();
      for(k=0;k<ectr;k++)
      printf("%s\n",expcode[k]);
    }

  pass2()
  {
  int j=0;
  while(j<i)
  {
    if(strcmpi(file[j],"macro\n")==0)
    {
   while(strcmpi(file[j],"mend\n")!=0)
   j++;
  }//if
  else
  {
     for(k=0;file[j][k]!=' '&&file[j][k]!='\n';k++)
     temp[k]=file[j][k];
     temp[k]='\0';
     for(p=0;p<mntcnt;p++)
     if(strcmpi(mnt[p].mname,temp)==0)
     break;
     if(p<mntcnt)
     {
	z=mnt[p].mdtpt;
	while(strcmpi(mdt[z],"mend")!=0)
	{
	for(k=0;mdt[z][k]!='#'&& mdt[z][k]!='\0';k++)
	temp[k]=mdt[z][k];
	temp[k]='\0';
	for(m=0;mdt[z][k]!='\0';k++,m++)
	temp1[m]=mdt[z][k];
	temp1[m]='\0';
	for(k=0;k<aptcnt;k++)
	if(strcmpi(temp1,apt[k].pos)==0)
	{
	strcat(temp,apt[k].name);
	strcpy(expcode[ectr],temp);
	ectr++;
	}
	z++;
       }
     }//if
    else
    {
      strcpy(expcode[ectr],file[j]);
      ectr++;

    }
  }//else

  j++;
  }//while

 }//pass2
//PROGRAM FOR CPU SCHEDULING

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>

int process[10],proc1[10],proc[20],cbt[10],arrival[10],
	     pri[10],time[10],wait[10],turn[10];
int n,m,i,j,k,ch,type,temp,diff,tq;
float avgw,avgt;

void main()
{
   clrscr();
   n=avgw=avgt=0;
   for(i=0 ; i<n ; i++)
   time[i] = 0;
   printf("enter the limit\n");
   scanf("%d",&n);
   printf("enter Processes\n");
   for(i=0;i<n;i++)
     scanf("%d",&process[i]);
   printf("enter CPU Birst Time\n");
   for(i=0;i<n;i++)
     scanf("%d",&cbt[i]);
   printf("enter Arrival Time\n");
   for(i=0;i<n;i++)
     scanf("%d",&arrival[i]);
       time[0] = 0;
   printf("Process\tCPU Burst Time\tArrival Time\n");
   for(i=0;i<n;i++)
     printf("%d\t\t%d\t\t%d\n", process[i],cbt[i],arrival[i]);
      printf("Enter the priority\n");
       for(i=0;i<n;i++)
	scanf("%d", &pri[i]);
	priority();
       printf("\n\nThe Waiting Time of Processes :\n");
      for(i=0;i<n;i++)
       for(j=i+1;j<n;j++)
	 if(proc1[i] ==proc1[j])
	   {
	     proc1[j]= proc1[j+1];
	     n--;
	    }

    for(i=0;i<n;i++)
    printf("Process %d = %d\n", proc1[i],wait[i]);
    printf("\nThe Turn Around Time of Processes :\n");
      for(i=0;i<n;i++)
      printf("Process %d = %d\n", proc1[i],turn[i]);
    printf("\nThe Average Waiting Time of Processes = %f\n",avgw);
    printf("\nThe Average Turn Around Time of Processes = %f\n",avgt);
    getch();

}

priority()
{
    for(i=0;i<n;i++)
       for(j=i+1;j<n;j++)
	 if(pri[i]>pri[j])
	 {
	   temp = pri[i];
	   pri[i] = pri[j];
	   pri[j] = temp;
	   temp = process[i];
	   process[i] = process[j];
	   process[j] = temp;
	   temp = cbt[i];
	   cbt[i] = cbt[j];
	   cbt[j] = temp;
	 }
	 for(i=0;i<n;i++)
	    arrival[i] = 0;
	    m=n+1;
      for(i=0;i<m;i++)
      time[i] = time[i-1] + cbt[i-1];
      k = m-1;
      print();

   //waiting time turn arround time
   for(i=0;i<n;i++)
   {
      wait[i] = time[i]- arrival[i];
      turn[i] = time[i+1]- arrival[i];
   }
   //average
   for(i=0;i<=m;i++)
   {
     avgw = avgw + wait[i] / n;
     avgt = avgt + turn[i] / n;
   }
   for(i=0;i<n;i++)
     proc1[i] = process[i];
  return;
}

print()
{
 printf("\nGantt Chart is \n\n");
    for(i=0;i<k;i++)
      printf("   %d\t",process[i]);
    printf("\n");
    for(i=0;i<k+1;i++)
      printf("%d\t",time[i]);
    getch();
 return;
 }
 import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

class Slip22_1 extends JFrame implements ActionListener
{
                JMenu m1,m2;
                JMenuBar mb;
                JMenuItem m[];

                StringBuffer ss=new StringBuffer();

                int n;
                int arr[]=new int [20];

                int n1,n2,gcd,pow;
                public Slip22_1()
                {
                                mb=new JMenuBar();

                                m1=new JMenu("Operation");
                                m2=new JMenu("Compute");

                                String str[]={"Accept","Exit","GCD","Power"};
                                m=new JMenuItem[str.length];
                                for(int i=0;i<str.length;i++)
                                {
                                                m[i]=new JMenuItem(str[i]);
                                                m[i].addActionListener(this);
                                }

                                mb.add(m1);
                                mb.add(m2);

                                m1.add(m[0]);
                                m1.add(m[1]);

                                m2.add(m[2]);
                                m2.add(m[3]);

                                setLayout(new BorderLayout());
                                add(mb,BorderLayout.NORTH);
                                setSize(300,150);
                                setVisible(true);
                                setLocation(500,200);
                                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                } // constructor
                public void actionPerformed(ActionEvent e)
                {
                                String s=e.getActionCommand();             //return the name of menu
                                if(s.equals("Exit"))
                                                System.exit(0);
                                if(s.equals("Accept"))
                                {
                                                n1=Integer.parseInt(JOptionPane.showInputDialog("Enter 1st no for Number"));
                                                n2=Integer.parseInt(JOptionPane.showInputDialog("Enter 2nd no for Number"));
                                }
                                if(s.equals("GCD"))
                                {
                                                int min;                                
                                                if(n1>=n2)
                                                                min=n1;
                                                else        min=n2;
                                                for(int i=1;i<=min;i++)
                                                {
                                                                if(n1%i==0 && n2%i==0)
                                                                                gcd=i;
                                                }
                                                JOptionPane.showMessageDialog(null,"GCD = "+gcd); 
                                }
                                if(s.equals("Power"))
                                {
                                                pow=1;                                

                                                for(int i=1;i<=n2;i++)
                                                {
                                                                pow=pow*n1;
                                                }
                                                JOptionPane.showMessageDialog(null,"Power = "+pow);           
                                }
                }
                public static void main(String a[])
                {
                                new Slip22_1();
                }
}
